#!/usr/bin/env bash

cd ..
$GOROOT/bin/go run main.go

